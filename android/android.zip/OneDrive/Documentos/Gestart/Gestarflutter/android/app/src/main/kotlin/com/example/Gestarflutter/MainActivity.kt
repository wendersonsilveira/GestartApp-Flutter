package com.gestart.gestartapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
