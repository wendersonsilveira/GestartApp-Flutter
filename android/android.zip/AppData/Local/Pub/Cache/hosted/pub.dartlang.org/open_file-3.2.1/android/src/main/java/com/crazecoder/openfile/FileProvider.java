package com.crazecoder.openfile;

public class FileProvider extends androidx.core.content.FileProvider {
}
